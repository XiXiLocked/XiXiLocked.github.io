import addressbook_pb2
from addressbook_pb2 import Person

def ParseMessage(typeDesc, values, obj):
    print "m1", typeDesc.name, values
    for ty, value in zip(typeDesc.fields, values):
        if   ty.label==2 :
            ParseRequired(ty, value, obj)
        elif ty.label==3 :
            ParseRepeated(ty, value, obj)
        else :#t.label ==1:
           pass

def ParseRequired(typeDesc, value, obj ):
    if not typeDesc.message_type:
        ParsePrimitive(typeDesc, value, obj)
    else:
        ParseMessage(typeDesc.message_type, value,
               eval("obj.{0}".format(typeDesc.name)))

def ParseRepeated(typeDesc, value, obj):
    if not typeDesc.message_type:
        ParsePrimitiveN(typeDesc, value, obj)
    else:
        ParseMessageN(typeDesc.message_type, value,
               eval("obj.{0}".format(typeDesc.name)))

def ParsePrimitive(typeDesc, value, obj ):
    print "p1", typeDesc.name, value
    exec("obj.{0} = value".format(typeDesc.name))

def ParsePrimitiveN(typeDesc, values, obj):
    print "pN",typeDesc.name, values
    for value in values:
        print "p1", typeDesc.name, value
        exec("obj.{0}.insert(-1,value)".format(typeDesc.name))

def ParseMessageN(typeDesc, values, obj):
    print "mN",typeDesc.name, values
    for value in values:
        ParseMessage(typeDesc, value, eval("obj.add()".format(typeDesc.name)))

if __name__ == "__main__":
    rrr = addressbook_pb2.Person()
    phonexx = ["John Doe",1234,["555-1234"], [['222222']]]
    ParseMessage(rrr.DESCRIPTOR, phonexx, rrr)
    print '----'*10
    print rrr


